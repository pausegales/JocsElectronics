#include "player.h"

Player::Player() {

	sprite.loadTGA("data/spritesheet.tga"); //example to load an sprite
	Vector2 initpos = Vector2(22, 33);
	Orientation facing = FRONT;
	bool is_moving = false;
	int fires_count = 0;
	int has_fight_element = 0;


}
