#pragma once

#include "includes.h"
#include "utils.h"

struct Camera {
	Vector2 position;
	Vector2 offset;
};