<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="dungeon1" tilewidth="16" tileheight="16" tilecount="512" columns="32">
 <image source="../../Tilemaps/dungeon1.png" trans="ff00ff" width="512" height="256"/>
</tileset>
