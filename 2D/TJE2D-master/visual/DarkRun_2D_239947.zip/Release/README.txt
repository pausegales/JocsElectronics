Pau Segalés Torres
239947
pau.segales01@estudiant.upf.edu